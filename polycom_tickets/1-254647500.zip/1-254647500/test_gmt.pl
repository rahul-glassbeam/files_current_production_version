#!/usr/bin/perl

use File::Find:Rule;
use Data::Dumper;

my $rule3 =  File::Find::Rule->new;
$rule3->file;
$rule3->name( qr/^.+\_.+\.txt$/ );
my @files_to_preprocess;
if( defined($dir_to_preprocess) ){
    @files_to_preprocess = $rule3->in( "$dir_to_preprocess" );
}
else{
    @files_to_preprocess = $rule3->in( "." );
}
my %gmt_offsets;
foreach my $file_to_preprocess(@files_to_preprocess){
    open(FHR, $file_to_preprocess) || die "read file handle error=$@, $!\n";
    my $gmt_offset;
    foreach my $line(<FHR>){        
        if( $line =~ /GMT Offset:/ ){
            chomp($line);
           ($gmt_offset) = $line =~ /GMT Offset:(.+)\s*$/;
           $gmt_offsets{$gmt_offset} = 1;
           last;
        }
    }
    if( !defined($gmt_offset) ){
        print "$file_to_preprocess doesnt have gmt offset\n";
    }
    close(FHR);
}
print Dumper(\%gmt_offsets);